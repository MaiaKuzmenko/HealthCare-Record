package model;

public class UnrecognizedVaccineCodeNameException extends Exception{

}
