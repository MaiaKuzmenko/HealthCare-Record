package model;
import static org.junit.Assert.assertEquals;
public class VaccinationSite {
	private String hospitalName;
	private int maxOfDose;
	private VaccineDistribution[] distributions = {};
	private HealthRecord[] appointments = {};
	
	public VaccinationSite(String hospitalName, int maxOfDose) {
		this.hospitalName = hospitalName;
		this.maxOfDose = maxOfDose;
	}
	
	public int getNumberOfAvailableDoses() {
		int sum = 0;		
		for(int i = 0; i < this.distributions.length; i++) {
			sum = sum + this.distributions[i].getNumOfDoses();
		}
		return sum;
	}
	
	public int getNumberOfAvailableDoses(String vaccineName) {
		int sum = 0;		
		for(int i = 0; i < this.distributions.length; i++) {
			if (vaccineName == this.distributions[i].getVaccine().getCodeName()) {
				sum = sum + this.distributions[i].getNumOfDoses();
			}			
		}
		return sum;
	}
	
	public void addDistribution(Vaccine vaccine, int numOfDose) throws UnrecognizedVaccineCodeNameException, TooMuchDistributionException {
		// check if it's recognized
		if (!vaccine.isRecognizedVaccine()) {
			throw new UnrecognizedVaccineCodeNameException();
		}
		
		// check if we exceed maxOfDose
		if (this.maxOfDose < numOfDose + this.getNumberOfAvailableDoses()) {
			throw new TooMuchDistributionException();
		}
		
		// find if it exists
		for(int i = 0; i < this.distributions.length; i++) {
			if (this.distributions[i].getVacineManufacturer() == vaccine.getManufacturer()) {
				// update vaccine quantity
				this.distributions[i].updateNumOfDoses(numOfDose);
				return; // don't need to add
			}
		}
		
		// add a new one
		VaccineDistribution[] newDistribution = new VaccineDistribution[this.distributions.length + 1];
		for(int i = 0; i < this.distributions.length; i++) {
			newDistribution[i] = this.distributions[i];
		}
		newDistribution[distributions.length] = new VaccineDistribution(vaccine, numOfDose);
		this.distributions = newDistribution;
	}
	
	public void bookAppointment(HealthRecord record) throws InsufficientVaccineDosesException{
		if (this.getNumberOfAvailableDoses() <= this.appointments.length) {
			record.setAppointment(hospitalName, false);
			throw new InsufficientVaccineDosesException();
		}
		
		HealthRecord[] newAppointments = new HealthRecord[this.appointments.length + 1];
		for(int i = 0; i < this.appointments.length; i++) {
			newAppointments[i] = this.appointments[i];
		}
		newAppointments[this.appointments.length] = record;
		this.appointments = newAppointments;
		
		record.setAppointment(hospitalName, true);
	}
	
	public void administer(String date) {
		int di = 0;
		for(int i=0; i<this.appointments.length; i++) {
			if(this.distributions[di].getNumOfDoses() == 0) {
				di = di + 1;
			}
			this.distributions[di].updateNumOfDoses(-1);
			this.appointments[i].addRecord(this.distributions[di].getVaccine(), this.hospitalName, date);
		}
		this.appointments = new HealthRecord[0];
	}
	
	public String toString() {
		if(this.distributions.length ==0) {
			return this.hospitalName + " has 0 available doses: <>";
		}
		
		int sum = 0;
		String doses = "";
		
		for(int i = 0; i < this.distributions.length; i++) {
			sum = sum + this.distributions[i].getNumOfDoses();
			if (i > 0) {
				doses = doses + ", ";
			}
			doses = doses + this.distributions[i].getNumOfDoses() + " doses of " + this.distributions[i].getVacineManufacturer();
		}
		
		// "North York General Hospital has 5 available doses: <3 doses of Moderna, 2 doses of Pfizer/BioNTech>
		
		return this.hospitalName + " has " + sum + " available doses: <" + doses + ">";
		//"North York General Hospital has 3 available doses: <3 doses of Moderna>"
		//"North York General Hospital has 0 available doses: <>"
	}
}
