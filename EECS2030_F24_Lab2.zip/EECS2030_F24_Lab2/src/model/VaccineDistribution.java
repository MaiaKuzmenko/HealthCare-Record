package model;

public class VaccineDistribution {
	private Vaccine vaccine;
	private int numOfDoses;
	
	public VaccineDistribution(Vaccine vaccine, int numOfDoses) {
		this.vaccine = vaccine;
		this.numOfDoses = numOfDoses;
				
	}
	
	public String getVacineManufacturer() {
		return this.vaccine.getManufacturer();
	}
	
	public void updateNumOfDoses(int doses) {
		this.numOfDoses = this.numOfDoses + doses;
	}
	
	public int getNumOfDoses() {
		return this.numOfDoses;
	}

	public Vaccine getVaccine() {
		return this.vaccine;
	}

	
	public String toString() {
		return this.numOfDoses + " doses of " + vaccine.getCodeName() + " by " + vaccine.getManufacturer();
		//"10000 doses of mRNA-1273 by Moderna"
	}

}
 