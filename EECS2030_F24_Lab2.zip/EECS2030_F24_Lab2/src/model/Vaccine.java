package model;

public class Vaccine {
	private String codeName;
	private String type;
	private String manufacturer;
	private String[] recognizedVaccine = {"mRNA-1273", "BNT162b2", "Ad26.COV2.S", "AZD1222"};
	
	public Vaccine(String codeName, String type, String manufacturer) {
		this.codeName = codeName;
		this.type = type;
		this.manufacturer = manufacturer;
		
	}
	
	public boolean isRecognizedVaccine() {
		for(int i = 0; i < this.recognizedVaccine.length; i++) {
			if(this.codeName == this.recognizedVaccine[i]) {
				return true;
			}
		}
		
		return false;
	}
	
	public String getManufacturer() {
		return this.manufacturer;
	}
	
	public String getCodeName() {
		return this.codeName;
	}
	
	public String toString() {
		if(isRecognizedVaccine()) {
			return "Recognized vaccine: " + this.codeName + " (" + this.type + "; " + this.manufacturer + ")";
		}
		return "Unrecognized vaccine: " + this.codeName + " (" + this.type + "; " + this.manufacturer + ")";
	}

}
 