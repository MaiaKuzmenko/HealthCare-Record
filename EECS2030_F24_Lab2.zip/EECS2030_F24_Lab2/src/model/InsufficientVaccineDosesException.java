package model;

public class InsufficientVaccineDosesException extends Exception{

}
