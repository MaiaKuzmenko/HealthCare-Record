package model;
import static org.junit.Assert.assertEquals;
public class HealthRecord {
	private String name;
	private String hospitalNameForLastAppt = "";
	private Boolean lastAppointmentSuccess = false;
	private int vaccineDosage;
	private String[] records = {};
	
	public HealthRecord(String name, int vaccineDosage) {
		this.name = name;
		this.vaccineDosage = vaccineDosage;
		
	}
	
	public String getVaccinationReceipt() {
		if(records.length == 0) {
			return this.name + " has not yet received any doses.";
		}
		
		String receipt = "Number of doses " + this.name + " has received: " + this.records.length + " [";
		for(int i = 0; i < this.records.length; i++) {
			receipt = receipt + records[i];
			if(i != records.length - 1) {
				receipt = receipt + "; " ;
			}
		}
		return receipt + "]";
		//no vac history: return this.name + " has not yet received any doses."
		//what there is vaccination history:
		//"Number of doses " this.name + " has received: " + this.vaccineDosage + " [Recognized vaccine: " + mRNA-1273 (RNA; Moderna) +
		//" in " + North York General Hospital + " on " + "April-20-2021]"
		
		// Recognized vaccine: mRNA-1273 (RNA; Moderna) in North York General Hospital on April-20-2021]", rec.getVaccinationReceipt());
	}
	
	public String getAppointmentStatus() {
		if (this.hospitalNameForLastAppt == "") {
			return "No vaccination appointment for " + this.name + " yet";
		}
		
		String message = "Last vaccination appointment for " + this.name + " with " + this.hospitalNameForLastAppt + " ";
		if (this.lastAppointmentSuccess) {
			message = message + "succeeded";
		} else {
			message = message + "failed";
		}
		return message;
		
		//check the appointment if there is or if there isnt
		//When no appointment status: "No vaccination appointment for " this.name + " yet"
		//When appointment "Last vaccination appointment for " this.name + " with " + North York General Hospital succeeded
	}
	
	public void setAppointment(String hospital, Boolean isSuccess) {
		this.hospitalNameForLastAppt = hospital;
		this.lastAppointmentSuccess = isSuccess;
	}
	
	public void addRecord(Vaccine vaccine, String hospital, String date) {
		//add record
		String[] newRecord = new String[this.records.length + 1];
		for(int i = 0; i < this.records.length; i++) {
			newRecord[i] = this.records[i];
		}
		newRecord[this.records.length] = vaccine + " in " + hospital + " on " + date;
		records = newRecord;
	}
}
